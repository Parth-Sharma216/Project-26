## Ingredients
3 carots
2 cups flour
1 cup milk
1 egg
1 cup sugar
1/2 cup sour cream