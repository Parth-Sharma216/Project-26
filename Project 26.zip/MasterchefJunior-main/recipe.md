## Recipe
Mix together flour and sugar in a bowl.
Mix together sour cream, egg, and milk in a seperate bowl.
Mix both mixtures together and gradually add in grated carrot.
Put in 2 pans and bake for 20 minutes.